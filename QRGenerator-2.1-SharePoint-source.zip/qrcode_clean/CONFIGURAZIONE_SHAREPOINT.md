# Registrazione delle scansioni in QRcodes.xlsx

## Perche serve un collegamento intermedio

Il link SharePoint di `QRcodes.xlsx` apre il file ma non autorizza un QR a
modificarlo. Il QR deve aprire una piccola app aziendale autenticata; l'app chiama
un flusso Power Automate che aggiunge la riga in Excel.

Flusso consigliato:

`Fotocamera smartphone -> QR -> Power Apps -> Power Automate -> QRcodes.xlsx`

In questo modo l'utente deve avere accesso all'ambiente Accelleron e al flusso.

## 1. Preparare il file Excel

Nel foglio di `QRcodes.xlsx`:

1. creare le intestazioni esatte `DESCRIZIONE` e `SERIAL`;
2. selezionare intestazioni e area dati;
3. scegliere **Inserisci > Tabella**;
4. assegnare alla tabella il nome `QR_LOG`;
5. chiudere il file prima delle prime prove del flusso.

Il connettore Excel Online scrive in una *tabella*, non in un intervallo libero.

## 2. Creare il flusso Power Automate

Creare un flusso istantaneo chiamato `RegistraQR`:

1. trigger **Power Apps (V2)**;
2. aggiungere due input di testo chiamati `description` e `serial`;
3. aggiungere **Excel Online (Business) > Aggiungi una riga in una tabella**;
4. selezionare il sito SharePoint e il file `QRcodes.xlsx`;
5. selezionare la tabella `QR_LOG`;
6. associare `description` alla colonna `DESCRIZIONE`;
7. associare `serial` alla colonna `SERIAL`;
8. salvare e condividere il flusso con gli utenti aziendali interessati.

## 3. Creare la piccola Power App

Creare un'app Canvas per telefono e collegare il flusso `RegistraQR`.

Nella proprieta `OnStart` dell'app usare una logica equivalente a:

```powerfx
If(
    !IsBlank(Param("description")) && !varRegistrato,
    Set(varRegistrato, true);
    RegistraQR.Run(
        Param("description"),
        Coalesce(Param("serial"), "")
    )
)
```

Mostrare poi un testo di conferma, per esempio “Registrazione completata”. La
variabile `varRegistrato` impedisce un secondo inserimento nella stessa sessione.

Pubblicare l'app e condividerla con gli utenti che eseguiranno le scansioni.

## 4. Configurare QR Generator

Recuperare da Power Apps il **collegamento Web** dell'app. Deve avere una forma
simile a:

```text
https://apps.powerapps.com/play/e/ENVIRONMENT/a/APP?tenantId=TENANT
```

In QR Generator aprire:

**Opzioni > Configura registrazione SharePoint**

Incollare il collegamento Web, salvarlo e lasciare selezionata l'opzione
**Registra la scansione su SharePoint**.

Il programma aggiunge automaticamente al link:

```text
&description=TESTO_CODIFICATO&serial=NUMERO_SERIALE
```

I caratteri speciali e gli spazi vengono codificati correttamente.

## 5. Collaudo

1. Generare un QR con descrizione `PROVA` e seriale `TEST-001`.
2. Scansionarlo con uno smartphone aziendale autenticato.
3. Attendere la conferma della Power App.
4. Verificare in `QRcodes.xlsx` la nuova riga `PROVA | TEST-001`.
5. Ripetere la scansione: deve essere aggiunta una nuova riga.

## Note operative

- Ogni scansione apre la Power App e genera una nuova riga.
- Se `SERIAL` e vuoto, la riga viene comunque aggiunta.
- Non inserire nel QR il collegamento diretto a `QRcodes.xlsx`: apre il file ma non
  esegue alcuna scrittura.
- Il proprietario del flusso deve avere accesso in modifica al file e alla tabella.
- Per evitare blocchi, non tenere il file aperto nell'app desktop durante il primo
  collaudo del connettore Excel.
