from __future__ import annotations

import json
from dataclasses import asdict, dataclass

from .paths import data_directory


@dataclass(slots=True)
class AppSettings:
    registration_url: str = ""


class SettingsStore:
    def __init__(self) -> None:
        self.filename = data_directory() / "settings.json"

    def load(self) -> AppSettings:
        if not self.filename.exists():
            return AppSettings()
        try:
            values = json.loads(self.filename.read_text(encoding="utf-8"))
            return AppSettings(registration_url=str(values.get("registration_url", "")))
        except (OSError, ValueError, TypeError):
            return AppSettings()

    def save(self, settings: AppSettings) -> None:
        self.filename.write_text(
            json.dumps(asdict(settings), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
