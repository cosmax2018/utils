from __future__ import annotations

from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import qrcode
from PIL import Image
from qrcode.image.svg import SvgPathImage


class QRService:
    def __init__(self, error_level: str = "H") -> None:
        self.error_level = error_level
        self.foreground = "black"
        self.background = "white"
        self.border = 4
        self.box_size = 10
        self.logo: Image.Image | None = None

    @property
    def correction(self) -> int:
        levels = {
            "L": qrcode.constants.ERROR_CORRECT_L,
            "M": qrcode.constants.ERROR_CORRECT_M,
            "Q": qrcode.constants.ERROR_CORRECT_Q,
            "H": qrcode.constants.ERROR_CORRECT_H,
        }
        return levels.get(self.error_level, levels["H"])

    def set_logo(self, filename: str | Path | None) -> None:
        if self.logo:
            self.logo.close()
        self.logo = Image.open(filename).convert("RGBA") if filename else None

    def create(self, text: str) -> Image.Image:
        if not text.strip():
            raise ValueError("Il contenuto del QR e vuoto")
        qr = qrcode.QRCode(
            error_correction=self.correction,
            box_size=self.box_size,
            border=self.border,
        )
        qr.add_data(text)
        qr.make(fit=True)
        image = qr.make_image(
            fill_color=self.foreground, back_color=self.background
        ).convert("RGB")
        return self._add_logo(image) if self.logo else image

    def _add_logo(self, image: Image.Image) -> Image.Image:
        logo = self.logo.copy()
        maximum = image.width // 5
        logo.thumbnail((maximum, maximum), Image.Resampling.LANCZOS)
        x = (image.width - logo.width) // 2
        y = (image.height - logo.height) // 2
        image.paste(logo, (x, y), logo)
        return image

    def save_svg(self, text: str, filename: str | Path) -> None:
        qr = qrcode.QRCode(
            error_correction=self.correction,
            box_size=self.box_size,
            border=self.border,
            image_factory=SvgPathImage,
        )
        qr.add_data(text)
        qr.make(fit=True)
        qr.make_image().save(filename)


def build_registration_url(base_url: str, description: str, serial: str = "") -> str:
    """Aggiunge i dati del QR a un deep link Power Apps/Power Automate."""
    if not base_url.strip():
        raise ValueError("Configurare prima il collegamento di registrazione SharePoint")
    if not description.strip():
        raise ValueError("La descrizione e obbligatoria")
    parts = urlsplit(base_url.strip())
    if parts.scheme != "https" or not parts.netloc:
        raise ValueError("Il collegamento di registrazione deve essere un indirizzo HTTPS valido")
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query["description"] = description.strip()
    query["serial"] = serial.strip()
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))
