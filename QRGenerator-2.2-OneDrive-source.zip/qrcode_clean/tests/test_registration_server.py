import http.client
import unittest
from pathlib import Path
from urllib.parse import urlencode

from openpyxl import load_workbook

from qr_app.registration_server import ExcelRegister, RegistrationServer


class RegistrationServerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.filename = Path(__file__).parent / "_test_qrcodes.xlsx"
        self.filename.unlink(missing_ok=True)
        self.register = ExcelRegister(self.filename, "Scansioni")

    def tearDown(self) -> None:
        self.filename.unlink(missing_ok=True)

    def test_prepare_and_append(self) -> None:
        self.register.prepare()
        row = self.register.append("Motore principale", "SN-100")
        workbook = load_workbook(self.filename, read_only=True)
        sheet = workbook["Scansioni"]
        self.assertEqual(sheet["A1"].value, "QRCODES")
        self.assertEqual(sheet["A2"].value, "DESCRIZIONE")
        self.assertEqual(sheet["B2"].value, "SERIALE")
        self.assertEqual(row, 3)
        self.assertEqual(sheet["A3"].value, "Motore principale")
        self.assertEqual(sheet["B3"].value, "SN-100")
        workbook.close()

    def test_preview_get_does_not_write_but_post_does(self) -> None:
        server = RegistrationServer(self.register, 0)
        server.start()
        try:
            port = server.httpd.server_address[1]
            connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
            connection.request("GET", "/register?description=Prova&serial=001")
            self.assertEqual(connection.getresponse().status, 200)
            self.register.prepare()
            workbook = load_workbook(self.filename, read_only=True)
            self.assertEqual(workbook["Scansioni"].max_row, 2)
            workbook.close()

            body = urlencode({"description": "Prova", "serial": "001"})
            connection.request(
                "POST",
                "/record",
                body=body,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            self.assertEqual(connection.getresponse().status, 200)
            workbook = load_workbook(self.filename, read_only=True)
            self.assertEqual(workbook["Scansioni"]["A3"].value, "Prova")
            workbook.close()
            connection.close()
        finally:
            server.stop()


if __name__ == "__main__":
    unittest.main()
