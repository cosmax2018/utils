from __future__ import annotations

import logging
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font


DEFAULT_WORKBOOK = Path(
    r"C:\Users\ITMACOS\OneDrive - Accelleron-Industries\Documents\QRcodes.xlsx"
)


class ExcelRegister:
    def __init__(self, filename: str | Path, sheet_name: str = "QRCODES") -> None:
        self.filename = Path(filename)
        self.sheet_name = sheet_name.strip() or "QRCODES"
        self._lock = threading.Lock()

    def prepare(self) -> None:
        with self._lock:
            self.filename.parent.mkdir(parents=True, exist_ok=True)
            if self.filename.exists():
                workbook = load_workbook(self.filename)
                sheet = workbook[self.sheet_name] if self.sheet_name in workbook.sheetnames else workbook.create_sheet(self.sheet_name)
            else:
                workbook = Workbook()
                sheet = workbook.active
                sheet.title = self.sheet_name
            self._format(sheet)
            workbook.save(self.filename)
            workbook.close()

    @staticmethod
    def _format(sheet) -> None:
        sheet["A1"] = "QRCODES"
        sheet["A1"].font = Font(bold=True, size=14)
        sheet["A2"] = "DESCRIZIONE"
        sheet["B2"] = "SERIALE"
        for cell in sheet[2]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="center")
        sheet.column_dimensions["A"].width = 55
        sheet.column_dimensions["B"].width = 25
        sheet.freeze_panes = "A3"

    def append(self, description: str, serial: str = "") -> int:
        description = description.strip()
        serial = serial.strip()
        if not description:
            raise ValueError("Descrizione mancante")
        if len(description) > 4000 or len(serial) > 500:
            raise ValueError("Dati troppo lunghi")
        with self._lock:
            self.prepare_unlocked()
            workbook = load_workbook(self.filename)
            sheet = workbook[self.sheet_name]
            row = max(sheet.max_row + 1, 3)
            sheet.cell(row=row, column=1, value=description)
            sheet.cell(row=row, column=2, value=serial)
            workbook.save(self.filename)
            workbook.close()
            return row

    def prepare_unlocked(self) -> None:
        self.filename.parent.mkdir(parents=True, exist_ok=True)
        if self.filename.exists():
            workbook = load_workbook(self.filename)
            sheet = workbook[self.sheet_name] if self.sheet_name in workbook.sheetnames else workbook.create_sheet(self.sheet_name)
        else:
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = self.sheet_name
        self._format(sheet)
        workbook.save(self.filename)
        workbook.close()


def local_ip_address() -> str:
    connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        connection.connect(("8.8.8.8", 80))
        return str(connection.getsockname()[0])
    except OSError:
        return socket.gethostbyname(socket.gethostname())
    finally:
        connection.close()


class RegistrationServer:
    def __init__(self, register: ExcelRegister, port: int = 8765) -> None:
        self.register = register
        self.port = port
        self.httpd: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self.httpd is not None

    def start(self) -> None:
        if self.running:
            return
        register = self.register

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                parts = urlsplit(self.path)
                if parts.path != "/register":
                    self.send_error(404)
                    return
                self._reply(
                    200,
                    "<h1 id='title'>Registrazione in corso...</h1>"
                    "<p id='message'>Attendere qualche secondo.</p>"
                    "<script>fetch('/record',{method:'POST',headers:{'Content-Type':"
                    "'application/x-www-form-urlencoded'},body:location.search.slice(1)})"
                    ".then(async r=>({ok:r.ok,data:await r.json()})).then(x=>{"
                    "document.getElementById('title').textContent=x.ok?'Registrazione completata':"
                    "'Registrazione non riuscita';document.getElementById('message').textContent="
                    "x.ok?'Riga '+x.data.row+' - '+x.data.description:x.data.error;})"
                    ".catch(()=>{document.getElementById('title').textContent='PC non raggiungibile';"
                    "document.getElementById('message').textContent='Verificare rete e QR Generator.';});"
                    "</script>",
                )

            def do_POST(self) -> None:
                if self.path != "/record":
                    self.send_error(404)
                    return
                length = min(int(self.headers.get("Content-Length", "0")), 10000)
                values = parse_qs(self.rfile.read(length).decode("utf-8"), keep_blank_values=True)
                description = values.get("description", [""])[0]
                serial = values.get("serial", [""])[0]
                try:
                    row = register.append(description, serial)
                    self._json(200, {"row": row, "description": description, "serial": serial})
                except Exception as exc:
                    logging.exception("Registrazione QR non riuscita")
                    self._json(500, {"error": str(exc)})

            def _json(self, status: int, value: dict) -> None:
                import json
                data = json.dumps(value, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _reply(self, status: int, content: str) -> None:
                page = (
                    "<!doctype html><html><head><meta name='viewport' "
                    "content='width=device-width,initial-scale=1'>"
                    "<style>body{font-family:sans-serif;max-width:600px;margin:40px auto;"
                    "padding:20px}h1{color:#176b34}</style></head><body>"
                    f"{content}</body></html>"
                ).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(page)))
                self.end_headers()
                self.wfile.write(page)

            def log_message(self, message: str, *args) -> None:
                logging.info("Registro QR: " + message, *args)

        self.httpd = ThreadingHTTPServer(("0.0.0.0", self.port), Handler)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None
            self.thread = None

    def registration_url(self, description: str, serial: str = "") -> str:
        query = urlencode({"description": description.strip(), "serial": serial.strip()})
        port = self.httpd.server_address[1] if self.httpd else self.port
        return f"http://{local_ip_address()}:{port}/register?{query}"
