from __future__ import annotations

import json
from dataclasses import asdict, dataclass

from .paths import data_directory


@dataclass(slots=True)
class AppSettings:
    workbook_path: str = str(
        r"C:\Users\ITMACOS\OneDrive - Accelleron-Industries\Documents\QRcodes.xlsx"
    )
    sheet_name: str = "QRCODES"
    registration_port: int = 8765


class SettingsStore:
    def __init__(self) -> None:
        self.filename = data_directory() / "settings.json"

    def load(self) -> AppSettings:
        if not self.filename.exists():
            return AppSettings()
        try:
            values = json.loads(self.filename.read_text(encoding="utf-8"))
            return AppSettings(
                workbook_path=str(values.get("workbook_path", AppSettings().workbook_path)),
                sheet_name=str(values.get("sheet_name", "QRCODES")),
                registration_port=int(values.get("registration_port", 8765)),
            )
        except (OSError, ValueError, TypeError):
            return AppSettings()

    def save(self, settings: AppSettings) -> None:
        self.filename.write_text(
            json.dumps(asdict(settings), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
