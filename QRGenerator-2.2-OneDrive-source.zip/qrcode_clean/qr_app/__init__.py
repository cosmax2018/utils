"""QR Generator: applicazione desktop per QR ed inventario."""

__version__ = "2.2.0"
