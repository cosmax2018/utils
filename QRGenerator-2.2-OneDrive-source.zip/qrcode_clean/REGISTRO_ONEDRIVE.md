# Registro QR in OneDrive

QR Generator usa il PC come ricevitore delle scansioni. Lo smartphone apre il
collegamento contenuto nel QR; il programma aggiunge `DESCRIZIONE` e `SERIALE` nel
file Excel locale sincronizzato da OneDrive.

## Requisiti

- QR Generator deve rimanere aperto sul PC.
- PC e smartphone devono potersi raggiungere sulla stessa rete aziendale.
- Windows Firewall deve consentire a QR Generator/Python l'accesso sulle reti
  private o aziendali.
- OneDrive deve essere attivo sul PC.
- Durante una registrazione, `QRcodes.xlsx` non deve essere bloccato da Excel.

## File predefinito

```text
C:\Users\ITMACOS\OneDrive - Accelleron-Industries\Documents\QRcodes.xlsx
```

Il pulsante **Prepara registro** crea il file, se non esiste, con:

| Cella | Valore |
|---|---|
| A1 | QRCODES |
| A2 | DESCRIZIONE |
| B2 | SERIALE |

Le registrazioni iniziano dalla riga 3. Il percorso e il nome del foglio possono
essere cambiati da **Opzioni > Configura registro OneDrive**.

## Utilizzo

1. Aprire QR Generator sul PC.
2. Premere **Prepara registro**.
3. Lasciare selezionato **Registra la scansione nel file OneDrive**.
4. Inserire descrizione e seriale e premere **Crea QR**.
5. Salvare o stampare il QR.
6. Scansionarlo dallo smartphone e aprire il collegamento suggerito.
7. Attendere la pagina “Registrazione completata”.

La semplice anteprima del collegamento non scrive il file: la registrazione viene
eseguita dalla pagina aperta, riducendo inserimenti involontari causati dalle
anteprime automatiche della fotocamera.

## Risoluzione dei problemi

- **PC non raggiungibile:** controllare che QR Generator sia aperto, che il PC non
  sia in sospensione e che i dispositivi siano sulla stessa rete.
- **Registrazione non riuscita:** chiudere temporaneamente `QRcodes.xlsx` in Excel
  e riprovare.
- **Nessuna sincronizzazione:** controllare lo stato dell'icona OneDrive.
- **Indirizzo del PC cambiato:** rigenerare i QR, perché contengono l'indirizzo di
  rete del PC al momento della creazione.

Per QR permanenti è opportuno assegnare al PC un indirizzo IP riservato tramite
DHCP oppure un nome DNS aziendale stabile.
